# -*- coding: utf-8 -*-
"""خادم الدليل الطبي - شبكة LAN / المنفذ 8000
قاعدة بيانات مركزية SQLite مع مزامنة آمنة بين جميع الأجهزة.
لا يحتاج إلى أي مكتبات خارجية.
"""
import json, os, sqlite3, threading, shutil, datetime, sys, gzip
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, quote, unquote

HOST='0.0.0.0'
PORT=8000
ROOT=os.path.dirname(os.path.abspath(__file__))
DB_PATH=os.path.join(ROOT,'medical_directory.db')
BACKUP_DIR=os.path.join(ROOT,'backups')
INDEX_FILE='الدليل_الطبي.html'
LOCK=threading.RLock()
EMPTY_STATE={'revision':0,'services':[],'serviceTypes':[],'users':[],'changeLog':[],'messages':[]}


def now_iso():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def db_connect():
    c=sqlite3.connect(DB_PATH,timeout=30)
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('PRAGMA synchronous=FULL')
    c.execute('PRAGMA busy_timeout=30000')
    c.execute('CREATE TABLE IF NOT EXISTS app_state (id INTEGER PRIMARY KEY CHECK(id=1), revision INTEGER NOT NULL, data TEXT NOT NULL, updated_at TEXT NOT NULL)')
    c.execute('CREATE TABLE IF NOT EXISTS state_history (revision INTEGER PRIMARY KEY, data TEXT NOT NULL, updated_at TEXT NOT NULL)')
    c.execute('CREATE TABLE IF NOT EXISTS mail_attachments (id TEXT PRIMARY KEY, name TEXT NOT NULL, mime_type TEXT, size INTEGER NOT NULL, data BLOB NOT NULL, created_at TEXT NOT NULL)')
    c.commit()
    return c


def clean_state(payload, revision=0):
    messages=[]
    raw_messages=payload.get('messages') if isinstance(payload.get('messages'),list) else []
    for m in raw_messages:
        if not isinstance(m,dict): continue
        x=dict(m)
        att=x.get('attachment')
        if isinstance(att,dict):
            # Never return/store the binary attachment inside the normal state response.
            # The file is kept separately in mail_attachments and fetched only on demand.
            x['attachment']={k:att.get(k) for k in ('id','name','size','type') if att.get(k) is not None}
        messages.append(x)
    return {
        'revision':int(revision),
        'services':payload.get('services') if isinstance(payload.get('services'),list) else [],
        'serviceTypes':payload.get('serviceTypes') if isinstance(payload.get('serviceTypes'),list) else [],
        'users':payload.get('users') if isinstance(payload.get('users'),list) else [],
        'changeLog':payload.get('changeLog') if isinstance(payload.get('changeLog'),list) else [],
        'messages':messages,
    }


def save_attachment(attachment_id, name, mime_type, data):
    if not attachment_id: raise ValueError('missing_attachment_id')
    if len(data)>8*1024*1024: raise ValueError('attachment_too_large')
    with LOCK:
        c=db_connect()
        c.execute('INSERT OR REPLACE INTO mail_attachments(id,name,mime_type,size,data,created_at) VALUES(?,?,?,?,?,?)',(attachment_id,name or 'attachment',mime_type or 'application/octet-stream',len(data),sqlite3.Binary(data),now_iso()))
        c.commit(); c.close()


def get_attachment(attachment_id):
    with LOCK:
        c=db_connect(); row=c.execute('SELECT name,mime_type,size,data FROM mail_attachments WHERE id=?',(attachment_id,)).fetchone(); c.close()
    return row


def load_state():
    with LOCK:
        c=db_connect()
        row=c.execute('SELECT revision,data FROM app_state WHERE id=1').fetchone()
        c.close()
        if not row: return None
        try:
            st=json.loads(row[1]); return clean_state(st,int(row[0])) if isinstance(st,dict) else None
        except Exception: return None


def load_history(c,revision):
    if revision is None or revision<0: return None
    row=c.execute('SELECT data FROM state_history WHERE revision=?',(int(revision),)).fetchone()
    if not row: return None
    try:
        st=json.loads(row[0]); return clean_state(st,int(revision)) if isinstance(st,dict) else None
    except Exception: return None


def map_by(items,key):
    out={}
    for x in items or []:
        if isinstance(x,dict):
            k=x.get(key)
            if k not in (None,''): out[str(k)]=x
    return out


def merge_array_by_key(base,current,incoming,key):
    """Three-way merge: preserve server changes while applying client changes since base."""
    b=map_by(base,key); cur=map_by(current,key); inc=map_by(incoming,key)
    result=dict(cur)
    # Client-added/changed/deleted records.
    for k,iv in inc.items():
        bv=b.get(k)
        if bv is None or iv != bv: result[k]=iv
    for k,bv in b.items():
        if k not in inc and k in result and result[k]==bv:
            result.pop(k,None)
    # Keep stable order: incoming first, then server-only.
    ordered=[]
    seen=set()
    for x in incoming or []:
        k=str(x.get(key)) if isinstance(x,dict) and x.get(key) not in (None,'') else None
        if k and k in result and k not in seen: ordered.append(result[k]); seen.add(k)
    for x in current or []:
        k=str(x.get(key)) if isinstance(x,dict) and x.get(key) not in (None,'') else None
        if k and k in result and k not in seen: ordered.append(result[k]); seen.add(k)
    return ordered


def merge_states(base,current,incoming):
    # Services are keyed by code where possible; messages by id; users by username; logs by id/timestamp.
    merged={'services':[], 'serviceTypes':[], 'users':[], 'changeLog':[], 'messages':[]}
    merged['services']=merge_array_by_key(base.get('services'),current.get('services'),incoming.get('services'),'code')
    merged['messages']=merge_array_by_key(base.get('messages'),current.get('messages'),incoming.get('messages'),'id')
    merged['users']=merge_array_by_key(base.get('users'),current.get('users'),incoming.get('users'),'username')
    merged['changeLog']=merge_array_by_key(base.get('changeLog'),current.get('changeLog'),incoming.get('changeLog'),'timestamp')
    # Service types: union, but honor explicit client additions/removals only when they differ from base.
    bs=set(map(str,base.get('serviceTypes') or [])); cs=list(current.get('serviceTypes') or []); ins=list(incoming.get('serviceTypes') or [])
    if ins != list(base.get('serviceTypes') or []):
        merged['serviceTypes']=ins
        for x in cs:
            if x not in merged['serviceTypes']: merged['serviceTypes'].append(x)
    else: merged['serviceTypes']=cs
    return merged


def save_state(payload):
    if not isinstance(payload,dict): raise ValueError('invalid state')
    incoming=clean_state(payload,0)
    try: base_rev=int(payload.get('_baseRevision',-1))
    except Exception: base_rev=-1
    with LOCK:
        c=db_connect()
        row=c.execute('SELECT revision,data FROM app_state WHERE id=1').fetchone()
        current=clean_state(json.loads(row[1]),int(row[0])) if row else clean_state(EMPTY_STATE,0)
        if row and base_rev>=0 and base_rev!=current['revision']:
            base=load_history(c,base_rev)
            if base is not None:
                merged=merge_states(base,current,incoming)
            else:
                # No history available: preserve server records and append client-only records.
                merged=merge_states({'services':[],'serviceTypes':[],'users':[],'changeLog':[],'messages':[]},current,incoming)
        else:
            merged={k:incoming[k] for k in ('services','serviceTypes','users','changeLog','messages')}
        rev=current['revision']+1
        text=json.dumps(merged,ensure_ascii=False,separators=(',',':'))
        ts=now_iso()
        c.execute('BEGIN IMMEDIATE')
        c.execute('INSERT INTO app_state(id,revision,data,updated_at) VALUES(1,?,?,?) ON CONFLICT(id) DO UPDATE SET revision=excluded.revision,data=excluded.data,updated_at=excluded.updated_at',(rev,text,ts))
        c.execute('INSERT OR REPLACE INTO state_history(revision,data,updated_at) VALUES(?,?,?)',(rev,text,ts))
        c.execute('DELETE FROM state_history WHERE revision < ?', (max(1,rev-10),))
        c.commit(); c.close()
        make_backup_if_needed(rev,text)
        out=dict(merged); out['revision']=rev
        return out


def make_backup_if_needed(rev,text):
    if rev % 20 != 0: return
    os.makedirs(BACKUP_DIR,exist_ok=True)
    fn=os.path.join(BACKUP_DIR,'backup_%06d.json'%rev)
    try:
        with open(fn,'w',encoding='utf-8') as f: f.write(text)
        files=sorted(x for x in os.listdir(BACKUP_DIR) if x.endswith('.json'))
        for old in files[:-20]:
            try: os.remove(os.path.join(BACKUP_DIR,old))
            except OSError: pass
    except OSError: pass


def _gzip_bytes(data): return gzip.compress(data,compresslevel=6)

class Handler(SimpleHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def __init__(self,*args,**kwargs): super().__init__(*args,directory=ROOT,**kwargs)
    def _send_json(self,code,obj):
        data=json.dumps(obj,ensure_ascii=False,separators=(',',':')).encode('utf-8')
        gz='gzip' in self.headers.get('Accept-Encoding','').lower(); out=_gzip_bytes(data) if gz else data
        self.send_response(code); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(out))); self.send_header('Cache-Control','no-store'); self.send_header('Access-Control-Allow-Origin','*')
        if gz:self.send_header('Content-Encoding','gzip')
        self.end_headers(); self.wfile.write(out)
    def do_GET(self):
        parsed=urlparse(self.path); path=parsed.path
        if path in ('/','/index.html'):
            try:
                with open(os.path.join(ROOT,INDEX_FILE),'rb') as f:data=f.read()
                gz='gzip' in self.headers.get('Accept-Encoding','').lower(); out=_gzip_bytes(data) if gz else data
                self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(out))); self.send_header('Cache-Control','no-cache, no-store, must-revalidate')
                if gz:self.send_header('Content-Encoding','gzip')
                self.end_headers(); self.wfile.write(out)
            except OSError:self.send_error(404,'Medical Directory page not found')
            return
        if path=='/api/attachment':
            aid=parse_qs(parsed.query).get('id',[''])[0]
            if not aid:
                self._send_json(400,{'error':'missing_attachment_id'}); return
            row=get_attachment(aid)
            if not row:
                self._send_json(404,{'error':'attachment_not_found'}); return
            name,mime,size,data=row
            self.send_response(200); self.send_header('Content-Type',mime or 'application/octet-stream'); self.send_header('Content-Length',str(len(data))); self.send_header('Content-Disposition','attachment; filename*=UTF-8''%s'%quote(name or 'attachment')); self.send_header('Cache-Control','private, no-store'); self.send_header('Access-Control-Allow-Origin','*'); self.end_headers(); self.wfile.write(data); return
        if path=='/api/state':
            state=load_state()
            if state is None:
                self._send_json(404,{'error':'state_not_initialized','revision':0}); return
            try: client_rev=int(parse_qs(parsed.query).get('revision',['-1'])[0])
            except Exception: client_rev=-1
            if client_rev>=0 and client_rev>=state['revision']:
                self.send_response(204); self.send_header('Cache-Control','no-store'); self.send_header('Content-Length','0'); self.end_headers(); return
            self._send_json(200,state); return
        if path=='/api/health':
            st=load_state() or clean_state(EMPTY_STATE,0); self._send_json(200,{'ok':True,'revision':st['revision'],'database':DB_PATH,'writable':os.access(ROOT,os.W_OK)}); return
        if path=='/api/info':
            st=load_state() or clean_state(EMPTY_STATE,0); self._send_json(200,{'ok':True,'name':'الدليل الطبي','port':PORT,'revision':st['revision'],'database':DB_PATH,'python':sys.version.split()[0]}); return
        super().do_GET()
    def do_OPTIONS(self):
        self.send_response(204); self.send_header('Access-Control-Allow-Origin','*'); self.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS'); self.send_header('Access-Control-Allow-Headers','Content-Type,X-Attachment-ID,X-Attachment-Name,X-Attachment-Type'); self.send_header('Content-Length','0'); self.end_headers()

    def do_POST(self):
        parsed=urlparse(self.path); path=parsed.path
        if path=='/api/attachment':
            try:
                aid=parse_qs(parsed.query).get('id',[''])[0] or self.headers.get('X-Attachment-ID','')
                name=unquote(self.headers.get('X-Attachment-Name','attachment'))
                mime=self.headers.get('X-Attachment-Type','application/octet-stream')
                n=int(self.headers.get('Content-Length','0'))
                if not aid: self._send_json(400,{'error':'missing_attachment_id'}); return
                if n<=0 or n>8*1024*1024: self._send_json(413,{'error':'attachment_too_large'}); return
                data=self.rfile.read(n); save_attachment(aid,name,mime,data); self._send_json(200,{'ok':True,'id':aid,'name':name,'size':len(data)})
            except Exception as e:
                self._send_json(500,{'error':'attachment_save_failed','detail':str(e)})
            return
        if path!='/api/state': self._send_json(404,{'error':'not_found'}); return
        try:
            n=int(self.headers.get('Content-Length','0'))
            if n<=0 or n>120*1024*1024: self._send_json(413,{'error':'payload_too_large'}); return
            raw=self.rfile.read(n); payload=json.loads(raw.decode('utf-8')); state=save_state(payload); self._send_json(200,state)
        except Exception as e:
            self._send_json(500,{'error':'save_failed','detail':str(e)})
    def log_message(self,fmt,*args): print('[%s] %s'%(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),fmt%args))

def main():
    os.makedirs(BACKUP_DIR,exist_ok=True)
    print('='*62); print('الدليل الطبي - خادم قاعدة البيانات المركزية'); print('Python:',sys.version.split()[0]); print('العنوان: http://localhost:%d'%PORT); print('قاعدة البيانات:',DB_PATH); print('إيقاف الخادم: Ctrl+C'); print('='*62)
    try: server=ThreadingHTTPServer((HOST,PORT),Handler)
    except OSError as e: print('\nتعذر فتح المنفذ %d: %s'%(PORT,e)); input('اضغط Enter للخروج...'); return 1
    try: server.serve_forever()
    except KeyboardInterrupt: print('\nتم إيقاف الخادم.')
    finally: server.server_close()
    return 0
if __name__=='__main__': raise SystemExit(main())
