@echo off
setlocal
cd /d "%~dp0"
title Medical Directory Server
set "PYEXE="
if exist "C:\BioTime\Python311\python.exe" set "PYEXE=C:\BioTime\Python311\python.exe"
if not defined PYEXE if exist "C:\Python311\python.exe" set "PYEXE=C:\Python311\python.exe"
if not defined PYEXE if exist "%LocalAppData%\Programs\Python\Python311\python.exe" set "PYEXE=%LocalAppData%\Programs\Python\Python311\python.exe"
if not defined PYEXE (
  where py >nul 2>&1
  if not errorlevel 1 set "PYEXE=py -3"
)
if not defined PYEXE (
  where python >nul 2>&1
  if not errorlevel 1 set "PYEXE=python"
)
if not defined PYEXE (
  echo Python 3 was not found.
  echo.
  pause
  exit /b 1
)

echo ================================================
echo Medical Directory LAN Server
echo ================================================
echo.
echo Server: http://localhost:8000
echo Network: http://YOUR-SERVER-IP:8000
echo.
echo Keep this window open while using the system.
echo.
%PYEXE% -S lan_server.py
set "RC=%ERRORLEVEL%"
echo.
echo Server stopped. Exit code: %RC%
echo.
pause
endlocal
