@echo off
cd /d "%~dp0"
echo Checking Python...
if exist "C:\BioTime\Python311\python.exe" (
  echo Found: C:\BioTime\Python311\python.exe
  "C:\BioTime\Python311\python.exe" -S -c "import sys; print(sys.version); print(sys.executable)"
) else (
  echo C:\BioTime\Python311\python.exe was not found.
)
echo.
pause
